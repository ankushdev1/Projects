jQuery(document).ready(function(){
jQuery('.style_picker_color').wpColorPicker();
});    